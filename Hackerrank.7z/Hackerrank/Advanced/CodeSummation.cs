﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Advanced
{
    public class CodeSummation
    {
        public static void Solve()
        {
            int t = int.Parse(Console.ReadLine());

            List<BigInteger> output = new List<BigInteger>();

            for (int i = 0; i < t; i++)
            {
                Dictionary<Tuple<long, long, long>, long> dict = new Dictionary<Tuple<long, long, long>, long>();

                int[] NAndM = Console.ReadLine().Split(' ').Select(n => int.Parse(n)).ToArray();

                for (int j = 0; j < NAndM[1]; j++)
                {
                    string[] query = Console.ReadLine().Split(' ');

                    long[] elements = null;

                    if (query[0].Equals("UPDATE"))
                    {
                        elements = new long[4] {
                        long.Parse(query[1]),
                        long.Parse(query[2]),
                        long.Parse(query[3]),
                        long.Parse(query[4])
                        };

                        Tuple<long, long, long> tuple = new Tuple<long, long, long>(elements[0], elements[1], elements[2]);

                        if (!dict.ContainsKey(tuple))
                            dict.Add(tuple, elements[3]);
                        else
                            dict[tuple] = elements[3];
                    }
                    else
                    {
                        elements = new long[6] {
                        long.Parse(query[1]),
                        long.Parse(query[2]),
                        long.Parse(query[3]),
                        long.Parse(query[4]),
                        long.Parse(query[5]),
                        long.Parse(query[6])
                        };

                        Tuple<long, long, long> lowerBoundTuple = new Tuple<long, long, long>(elements[0], elements[1], elements[2]);
                        Tuple<long, long, long> upperBoundTuple = new Tuple<long, long, long>(elements[3], elements[4], elements[5]);

                        BigInteger sum = 0;
                        foreach (Tuple<long, long, long> index in dict.Keys)
                        {
                            if (ISInclusive(index, lowerBoundTuple, upperBoundTuple).Equals(true))
                            {
                                sum = BigInteger.Add(sum, dict[index]);
                            }
                        }
                        output.Add(sum);
                    }
                }
            }

            foreach (var item in output)
            {
                Console.WriteLine(item);
            }
        }
        public static bool ISInclusive(Tuple<long, long, long> inputTuple, Tuple<long, long, long> lowerBound, Tuple<long, long, long> upperBound)
        {
            bool flag = false;
            if (inputTuple.Item1 >= lowerBound.Item1 && inputTuple.Item1 <= upperBound.Item1)
                if (inputTuple.Item2 >= lowerBound.Item2 && inputTuple.Item2 <= upperBound.Item2)
                    if (inputTuple.Item3 >= lowerBound.Item3 && inputTuple.Item3 <= upperBound.Item3)
                        flag = true;
            return flag;
        }
    }
}
