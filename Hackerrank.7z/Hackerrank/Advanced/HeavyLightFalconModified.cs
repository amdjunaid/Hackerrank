﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced
{
    public class HeavyLightFalconModified
    {
        public static TextReader reader;
        public static TextWriter writer;
        const long N = 50000, NN = 65536;
        long[] chain = new long[N], dep = new long[N], dfn = new long[N], par = new long[N];
        long tick;
        long[] mx = new long[2 * NN];
        List<long>[] adj = new List<long>[N];
        List<long> output = new List<long>();

        public long dfs(long u, long p)
        {
            long size = 1, maxs = 0;
            par[u] = p;
            chain[u] = -1;
            foreach (long v in adj[u])
                if (v != p)
                {
                    dep[v] = dep[u] + 1;
                    long s = dfs(v, u);
                    size += s;
                    if (s > maxs)
                    {
                        maxs = s;
                        chain[u] = v;
                    }
                }
            return size;
        }

        public void hld(long u, long p, long top)
        {
            dfn[u] = tick++;
            if (chain[u] >= 0)
            {
                hld(chain[u], u, top);
                foreach (long v in adj[u])
                    if (v != p && v != chain[u])
                        hld(v, u, v);
            }
            chain[u] = top;
        }

        long get_max(long l, long r)
        {
            long ans = 0;
            for (l += NN, r += NN; l < r; l >>= 1, r >>= 1)
            {
                if ((l & 1).Equals(1)) ans = Math.Max(ans, mx[l++]);
                if ((r & 1).Equals(1)) ans = Math.Max(ans, mx[--r]);
            }
            return ans;
        }

        public void Solve()
        {
            int[] NAndQ = ReadIntArray();

            for (int i = 0; i < N; i++)
            {
                adj[i] = new List<long>();
            }

            for (int i = 1; i < NAndQ[0]; i++)
            {
                int[] edges = ReadIntArray(); //scan u and v
                adj[edges[0]].Add(edges[1]); // add v to adj[u]
                adj[edges[1]].Add(edges[0]);
            }

            dfs(0, -1); // dfs to set up depth, parent and subsize.
            hld(0, -1, 0);

            for (int i = 0; i < NAndQ[1]; i++)
            {
                int[] query = ReadIntArray();
                long u = query[1];
                long v = query[2];
                if (query[0].Equals(1))
                {
                    long index = dfn[u] + NN;
                    mx[index] = v;
                    while (index > 0)
                    {
                        index >>= 1;
                        mx[index] = Math.Max(mx[2 * index], mx[2 * index + 1]);
                    }
                }
                else
                {
                    long ans = 0;
                    while (chain[u] != chain[v])
                    {
                        if (dep[chain[u]] > dep[chain[v]])
                        {
                            ans = Math.Max(ans, get_max(dfn[chain[u]], dfn[u] + 1));
                            u = par[chain[u]];
                        }
                        else
                        {
                            ans = Math.Max(ans, get_max(dfn[chain[v]], dfn[v] + 1));
                            v = par[chain[v]];
                        }
                    }
                    if (dep[u] > dep[v])
                        ans = Math.Max(ans, get_max(dfn[v], dfn[u] + 1));
                    else
                        ans = Math.Max(ans, get_max(dfn[u], dfn[v] + 1));
                    output.Add(ans);
                }
            }

            foreach (long item in output)
            {
                Console.WriteLine(item);
            }

            //Console.ReadLine();
        }

        #region Read/Write

        private static Queue<string> currentLineTokens = new Queue<string>();
        private static string[] ReadAndSplitLine() { return reader.ReadLine().Split(new[] { ' ', '\t', }, StringSplitOptions.RemoveEmptyEntries); }
        public static string ReadToken() { while (currentLineTokens.Count == 0) currentLineTokens = new Queue<string>(ReadAndSplitLine()); return currentLineTokens.Dequeue(); }
        public static int ReadInt() { return int.Parse(ReadToken()); }
        public static long ReadLong() { return long.Parse(ReadToken()); }
        public static int[] ReadIntArray() { return ReadAndSplitLine().Select(int.Parse).ToArray(); }

        #endregion

    }
}
