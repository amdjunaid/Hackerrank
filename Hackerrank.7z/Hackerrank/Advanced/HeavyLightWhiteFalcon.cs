﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Advanced
{
    public class HeavyLightWhiteFalcon
    {
        public static TextReader reader;
        public static TextWriter writer;
        static int dfsTraversalCounter = 0;
        const long N = 50000, NN = 65536;
        List<long>[] graph = new List<long>[N];
        long[] depth , parent , chain;
        int[] dfsTraversalOrder;
        List<long> output = new List<long>();
        static SegmentTree<int> segmentTree = null;
        public void Solve()
        {
            int n = ReadInt();
            int q = ReadInt();

             graph = Enumerable.Repeat(0, n).Select(li => new List<long>()).ToArray();

            for (int i = 1; i < n; i++)
            {
                int u = ReadInt();
                int v = ReadInt();
                graph[u].Add(v);
                graph[v].Add(u);
            }

            parent = new long[N];
            dfsTraversalOrder = new int[N];
            depth = new long[N];
            chain = new long[N];

            DepthFirstSearch(0, -1);
            HeavyLightDecomposition(0, -1, 0);
            segmentTree = new SegmentTree<int>(Math.Max, dfsTraversalCounter);

            for(int i = 0;i<q;i++)
            {
                int queryOperation = ReadInt();
                int u = ReadInt();
                int v = ReadInt();

                if (queryOperation.Equals(1))
                {
                    segmentTree.Set(dfsTraversalOrder[u], v);
                }
                else
                {
                    output.Add(FindMaxEdge(u,v));
                }
            }

            foreach (var item in output)
            {
                writer.WriteLine(item);
            }

            HeavyLightWhiteFalcon.reader.Close();
            HeavyLightWhiteFalcon.writer.Close();
        }

        private long DepthFirstSearch(long currentNode, long parentNode)
        {
            long size = 1, maxSize = 0;
            parent[currentNode] = parentNode;
            chain[currentNode] = -1;

            foreach (long childNode in graph[currentNode])
            {
                if (childNode != parentNode)
                {
                    depth[childNode] = depth[currentNode] + 1;
                    long childNodeTreeSize = DepthFirstSearch(childNode, currentNode);
                    size += childNodeTreeSize;
                    if (childNodeTreeSize > maxSize)
                    {
                        chain[currentNode] = childNode;
                        maxSize = childNodeTreeSize;
                    }
                }
            }
            return size;
        }

        private void HeavyLightDecomposition(long currentNode, long parentNode, long chainHead)
        {
            dfsTraversalOrder[currentNode] = dfsTraversalCounter++;
            if (chain[currentNode] >= 0)
            {
                HeavyLightDecomposition(chain[currentNode], currentNode, currentNode);
                foreach (var childNode in graph[currentNode])
                {
                    if (childNode != parentNode && childNode != chain[currentNode])
                        HeavyLightDecomposition(childNode, currentNode, childNode);
                }
            }
            chain[currentNode] = chainHead;
        }

        private long FindMaxEdge(long u, long v)
        {
            int answer = 0;
            while (chain[u] != chain[v])
            {
                if (depth[chain[u]] > depth[chain[v]])
                {
                    answer = Math.Max(answer, segmentTree.Query(dfsTraversalOrder[chain[u]],dfsTraversalOrder[u] + 1));
                    u = parent[chain[u]];
                }
                else
                {
                    answer = Math.Max(answer, segmentTree.Query(dfsTraversalOrder[chain[v]],dfsTraversalOrder[v] + 1));
                    v = parent[chain[v]];
                }
            }
            if (depth[u] > depth[v])
                answer = segmentTree.func(answer, segmentTree.Query(dfsTraversalOrder[v], dfsTraversalOrder[u] + 1));
            else
                answer = segmentTree.func(answer, segmentTree.Query(dfsTraversalOrder[u], dfsTraversalOrder[v] + 1));
            return answer;
        }

        #region Read/Write

        private static Queue<string> currentLineTokens = new Queue<string>();
        private static string[] ReadAndSplitLine() { return reader.ReadLine().Split(new[] { ' ', '\t', }, StringSplitOptions.RemoveEmptyEntries); }
        public static string ReadToken() { while (currentLineTokens.Count == 0) currentLineTokens = new Queue<string>(ReadAndSplitLine()); return currentLineTokens.Dequeue(); }
        public static int ReadInt() { return int.Parse(ReadToken()); }
        public static long ReadLong() { return long.Parse(ReadToken()); }
        public static int[] ReadIntArray() { return ReadAndSplitLine().Select(int.Parse).ToArray(); }

        #endregion
    }
    public class SegmentTree<T>
    {
        static T obj = Activator.CreateInstance<T>();
        private T minValue = (dynamic)obj.GetType().GetField("MinValue").GetValue(obj) + (dynamic)obj.GetType().GetField("MaxValue").GetValue(obj) + (dynamic)1;
        private T[] data;
        public Func<T, T, T> func;
        private long size;
        public SegmentTree(Func<T, T, T> func, long size)
        {
            data = new T[size << 2];
            this.size = size;
            this.func = func;
        }

        public SegmentTree(Func<T, T, T> func, T[] arr)
            : this(func, arr.Length)
        {
            Build(arr, 1, 0, arr.Length - 1);
        }

        private void Build(T[] arr, int currentIndex, int startIndex, int endIndex)
        {
            if (startIndex.Equals(endIndex))
                data[currentIndex] = arr[startIndex];
            else
            {
                int middleSegment = startIndex + endIndex >> 1;
                Build(arr, currentIndex * 2, startIndex, middleSegment);
                Build(arr, currentIndex * 2 + 1, middleSegment + 1, endIndex);
                data[currentIndex] = func(data[currentIndex * 2], data[currentIndex * 2 + 1]);
            }
        }

        private T Query(int x, int xl, int xr, int l, int r)
        {
            if (l == xl && r == xr)
                return data[x];

            int xm = xl + xr >> 1;
            if (l <= xm && r > xm)
                return func(Query(x * 2, xl, xm, l, xm), Query(x * 2 + 1, xm + 1, xr, xm + 1, r));
            if (l <= xm)
                return Query(x * 2, xl, xm, l, r);
            return Query(x * 2 + 1, xm + 1, xr, l, r);
        }

        public T Query(int l, int r)
        {
            return Query(1, 0, (int)size - 1, l, r);
        }

        private void Set(int x, int xl, int xr, int idx, T v)
        {
            if (xl == xr)
                data[x] = v;
            else
            {
                int xm = xl + xr >> 1;
                if (idx <= xm)
                    Set(x * 2, xl, xm, idx, v);
                else
                    Set(x * 2 + 1, xm + 1, xr, idx, v);
                data[x] = func(data[x * 2], data[x * 2 + 1]);
            }
        }

        public void Set(int idx, T v)
        {
            Set(1, 0, (int)size - 1, idx, v);
        }

        //private T Query(int currentIndex, int startIndex, int endIndex, int queryStart, int queryEnd)
        //{
        //    if (queryStart == startIndex && queryEnd == endIndex)
        //        return data[currentIndex];

        //    int xm = startIndex + endIndex >> 1;
        //    if (queryStart <= xm && queryEnd > xm)
        //        return func(Query(currentIndex * 2, startIndex, xm, queryStart, xm), Query(currentIndex * 2 + 1, xm + 1, endIndex, xm + 1, queryEnd));
        //    if (queryStart <= xm)
        //        return Query(currentIndex * 2, startIndex, xm, queryStart, queryEnd);
        //    return Query(currentIndex * 2 + 1, xm + 1, endIndex, queryStart, queryEnd);
        //}

        //public T Query(int queryStart, int queryEnd)
        //{
        //    return Query(1, 0, (int)size - 1, queryStart, queryEnd);
        //}

        //private void Set(int currentIndex, int startIndex, int endIndex, int index, T newValue)
        //{
        //    if (startIndex == endIndex)
        //        data[currentIndex] = newValue;
        //    else
        //    {
        //        int xm = startIndex + endIndex >> 1;
        //        if (index <= xm)
        //            Set(currentIndex * 2, startIndex, xm, index, newValue);
        //        else
        //            Set(currentIndex * 2 + 1, xm + 1, endIndex, index, newValue);
        //        data[currentIndex] = func(data[currentIndex* 2], data[currentIndex * 2 + 1]);
        //    }
        //}

        //public void QueryUpdate(int index, T newValue)
        //{
        //    if (index < 0 || index > size - 1)
        //        return;
        //    Set(1, 0, (int)size - 1, index, newValue);
        //}
    }


}
