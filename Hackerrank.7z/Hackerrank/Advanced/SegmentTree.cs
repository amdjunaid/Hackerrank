﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced
{
    public class SegmentTree
    {
        int[] st; // array that holds segment tree

        /// <summary>
        /// construct segment tree from the given array and array size n.
        /// </summary>
        /// <param name="arr"></param>
        /// <param name="n"></param>
        public SegmentTree(int[] arr, int n)
        {
            int height = (int)(Math.Ceiling(Math.Log(n) / Math.Log(2)));

            int maxSize = 2 * (int)Math.Pow(2, height) - 1;

            st = new int[maxSize];

            ConstructST(arr, 0, n - 1, 0);
        }

        /// <summary>
        /// Construct segment tree
        /// </summary>
        /// <param name="arr">Input array</param>
        /// <param name="ss">starting index of segment tree</param>
        /// <param name="se">ending index of segment tree</param>
        /// <param name="si">current node index of segment tree</param>
        private int ConstructST(int[] arr, int ss, int se, int si)
        {
            if (ss == se) // if there is only one element, return it.
            {
                st[si] = arr[ss];
                return arr[ss];
            }

            int mid = GetMid(ss, se);

            st[si] = ConstructST(arr, ss, mid, 2 * si + 1) + ConstructST(arr, mid + 1, se, 2 * si + 2);

            return st[si];
        }

        private int GetMid(int s, int e)
        {
            return s + (e - s) / 2;
        }

        public int GetSum(int n, int qs, int qe)
        {
            if (qs < 0 || qe > n - 1 || qs > qe)
                return -1;
            return GetSumUtil(0, n - 1, qs, qe, 0);
        }

        /// <summary>
        /// Returns sum for query start index (qs) and ending index (qe) for segment tree between ss and se.
        /// si is current node index of segment tree
        /// </summary>
        /// <param name="ss"></param>
        /// <param name="se"></param>
        /// <param name="qs"></param>
        /// <param name="qe"></param>
        /// <param name="si"></param>
        /// <returns></returns>
        public int GetSumUtil(int ss, int se, int qs, int qe, int si)
        {
            //if segment of this node is part of given query, then return the value of this node
            if (qs <= ss && qe >= se)
                return st[si];

            //if segment of this node is out side the range of given query, then return 0.
            if (qs > se || ss > qe)
                return 0;

            int mid = GetMid(ss, se);

            return GetSumUtil(ss, mid, qs, qe, 2 * si + 1) + GetSumUtil(mid + 1, se, qs, qe, 2 * si + 2);
        }

        /// <summary>
        /// To update newValue in input array and segment tree
        /// </summary>
        /// <param name="arr"></param>
        /// <param name="n"></param>
        /// <param name="i"></param>
        /// <param name="newValue"></param>
        public void UpdateValue(int[] arr, int n, int i, int newValue)
        {
            if (i < 0 || i > n - 1)
            {
                Console.Write("Cannot Update!Error.");
                return;
            }
            int diff = newValue - arr[i];
            arr[i] = newValue;
            UpdateValueUtil(0, n - 1, i, diff, 0);
        }

        private void UpdateValueUtil(int ss, int se, int index, int diff, int si)
        {
            // if index is out of segment of current node.
            if (index > se || index < ss)
                return;

            // if index is within the range of current segment node, then update the difference.
            st[si] += diff;

            // until we reach the leaf node of segment tree, split the current segment and repeat the process
            if (ss != se)
            {
                int mid = GetMid(ss, se);
                UpdateValueUtil(ss, mid, index, diff, 2 * si + 1);
                UpdateValueUtil(mid + 1, se, index, diff, 2 * si + 2);
            }
        }

    }
}
