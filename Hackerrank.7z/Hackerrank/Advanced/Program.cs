﻿using System;
using System.Numerics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Advanced
{
    class Program
    {
        static void Main(string[] args)
        {
#if DEBUG
            HeavyLightWhiteFalcon.reader = new StreamReader("..\\..\\input.txt");
            HeavyLightWhiteFalcon.writer = new StreamWriter("..\\..\\output.txt");
#else
            HeavyLightWhiteFalcon.reader = new StreamReader(Console.OpenStandardInput());
            HeavyLightWhiteFalcon.writer = new StreamWriter(Console.OpenStandardOutput());
#endif
            try
            {
                HeavyLightWhiteFalcon f = new HeavyLightWhiteFalcon();
                var stackSize = 1000000000;
                Thread t = new Thread(f.Solve, stackSize);
                t.Start();
            }
            catch (Exception ex)
            {
#if DEBUG
                Console.WriteLine(ex);
#else
            throw;
#endif
            }
            
        }
    }
}
