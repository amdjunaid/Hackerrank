﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalancedTrees
{
    public class Node
    {
        public int value, size;
        public Node left, right;
        public Double priority;

        public Node(int val) {
            value = val;
            priority = ImplicitTreaps.randGen.Next();
            size = 1;
        }

    }

    public class NodePair
    {
        public Node left, right;

        public NodePair(Node left, Node right)
        {
            this.left = left;
            this.right = right;
        }
    }

    public class ImplicitTreaps
    {
        public static Node rootNode = null;
        public int Count { get; set; }
        public static Random randGen = new Random();

        public void Solve()
        {
            ImplicitTreaps treaps = new ImplicitTreaps();

            int[] inputs = Console.ReadLine().Split(' ').Select(n => int.Parse(n)).ToArray();
            int[] inputArray = Console.ReadLine().Split(' ').Select(n => int.Parse(n)).ToArray();

            for (int i = 0; i < inputArray.Length; i++)
            {
                rootNode = treaps.InsertAtI(rootNode, (i + 1), inputArray[i]);
            }

            for (int i = 0; i < inputs[1]; i++)
            {
                int[] query = Console.ReadLine().Split(' ').Select(n => int.Parse(n)).ToArray();

                int startIndex = query[1];
                int endIndex = query[2];

                if (query[0].Equals(1))
                {
                    Tuple<Node, Node> deletedNode = treaps.DeleteAtI(rootNode, startIndex, endIndex);
                    rootNode = deletedNode.Item1;
                    rootNode = treaps.InsertAtI(rootNode, 1, deletedNode.Item2);
                }
                else if (query[0].Equals(2))
                {
                    Tuple<Node, Node> deletedNode = treaps.DeleteAtI(rootNode, startIndex, endIndex);
                    rootNode = deletedNode.Item1;
                    rootNode = treaps.InsertAtI(rootNode, treaps.GetSize(rootNode) + 1, deletedNode.Item2);
                }
            }

            int c = treaps.GetNodeAtI(rootNode, 1, 0).value - treaps.GetNodeAtI(rootNode, treaps.GetSize(rootNode), 0).value;

            if (c < 0)
                c = c * -1;

            Console.WriteLine(c);

            for (int i = 0; i < treaps.GetSize(rootNode); i++)
                Console.Write(treaps.GetNodeAtI(rootNode, i + 1, 0).value + " ");
        }

        public int GetSize(Node root)
        {
            if (root == null)
                return 0;
            return root.size;
        }

        public Node UpdateSize(Node root)
        {
            if (root != null)
            {
                root.size = GetSize(root.left) + GetSize(root.right) + 1;
            }

            return root;
        }

        public Node Merge(Node T1, Node T2)
        {
            if (T1 == null)
                return T2;
            if (T2 == null)
                return T1;
            Node newNode = null;
            if (T1.priority > T2.priority)
            {
                T1.right = Merge(T1.right, T2);
                newNode = T1;
            }
            else
            {
                T2.left = Merge(T1, T2.left);
                newNode = T2;
            }
            return UpdateSize(newNode);
        }

        public NodePair Split(Node root, int position, int lowerCnt)
        {
            NodePair result = new NodePair(null, null);
            if (root == null)
                return result;
            int nKey = lowerCnt + GetSize(root.left) + 1;

            if (position < nKey) // if position to split is less than current node's key, then, traverse to left
            {
                result = Split(root.left, position, lowerCnt); // only lowerCnt.
                root.left = result.right;
                result.right = root;

                result.left = UpdateSize(result.left);
                result.right = UpdateSize(result.right);
                return result;
            }
            else
            {
                result = Split(root.right, position, lowerCnt + GetSize(root.left) + 1);
                root.right = result.left;
                result.left = root;

                result.left = UpdateSize(result.left);
                result.right = UpdateSize(result.right);
                return result;
            }
        }

        public Node InsertAtI(Node root, int key, int value)
        {
            Count++;
            NodePair results = Split(root, (key-1), 0);
            Node mergedNode = Merge(results.left, new Node(value));
            Node mergedNewTreapRoot = Merge(mergedNode, results.right);
            return mergedNewTreapRoot;
        }

        public Node InsertAtI(Node root, int key, Node treap)
        {
            Count++;
            NodePair results = Split(root, (key - 1), 0);
            Node mergedNode = Merge(results.left, treap);
            Node mergedNewTreapRoot = Merge(mergedNode, results.right);
            return mergedNewTreapRoot;
        }

        public Tuple<Node,Node> DeleteAtI(Node root, int key)
        {
            Count--;
            NodePair LAndR = Split(root, key-1, 0);
            NodePair LDashAndRDash = Split(LAndR.right, 1, 0);
            Node mergedNewTreapRoot = Merge(LAndR.left, LDashAndRDash.right);
            return new Tuple<Node,Node>(mergedNewTreapRoot, LDashAndRDash.left);
        }

        public Tuple<Node, Node> DeleteAtI(Node root, int startIndex, int endIndex)
        {
            //Count--;
            NodePair LAndR = Split(root, startIndex - 1, 0);
            NodePair LDashAndRDash = Split(LAndR.right, endIndex - GetSize(LAndR.left) , 0);
            Node mergedNewTreapRoot = Merge(LAndR.left, LDashAndRDash.right);
            return new Tuple<Node, Node>(mergedNewTreapRoot, LDashAndRDash.left);
        }

        public Node GetNodeAtI(Node root, int index, int lowerCnt)
        {
            int nKey = lowerCnt + GetSize(root.left) + 1;
            if (nKey > index)
            {
                return GetNodeAtI(root.left, index, lowerCnt);
            }
            else if (nKey < index)
            {
                return GetNodeAtI(root.right, index, lowerCnt + GetSize(root.left) + 1);
            }
            else
            {
                return root;
            }
        }
    }
}
