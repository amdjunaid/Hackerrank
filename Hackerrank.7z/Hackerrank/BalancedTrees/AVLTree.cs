﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalancedTrees
{
    namespace AVLTrees
    {
        public class Node
        {
            public int rank;
            public int val;
            public int ht;
            public Node left;
            public Node right;
        }
        class AVLTree
        {
            public static int GetRank(Node root)
            {
                if (root == null)
                    return 0;
                return root.rank;
            }

            public static Node insert(Node root, int val)
            {
                if (root == null)
                {
                    root = new Node();
                    root.rank = 1;
                    root.val = val;
                    root.ht = 0;
                    root.left = null;
                    root.right = null;
                    return root;
                }
                root.rank += 1;

                if (val < root.val)
                    root.left = insert(root.left, val);
                else
                    root.right = insert(root.right, val);

                root.ht = max(height(root.left), height(root.right)) + 1;

                return BalanceAVlTree(root);
            }

            public static bool Search(Node root, int val)
            {
                if (root == null)
                    return false;
                if (val < root.val)
                    return Search(root.left, val);
                else if (val > root.val)
                    return Search(root.right, val);
                else
                    return true;
            }

            public static Node BalanceAVlTree(Node root)
            {
                int balanceFactor = GetBalance(root);

                if (balanceFactor > 1 && GetBalance(root.left) >= 0) // Left - left
                {
                    return RightRotate(root);
                }
                else if (balanceFactor > 1 && GetBalance(root.left) < 0) // Left - right
                {
                    root.left = LeftRotate(root.left);
                    return RightRotate(root);
                }
                else if (balanceFactor < -1 && GetBalance(root.right) <= 0) // right - right
                {
                    return LeftRotate(root);
                }
                else if (balanceFactor < -1 && GetBalance(root.right) > 0) // right - left
                {
                    root.right = RightRotate(root.right);
                    return LeftRotate(root);
                }
                return root;
            }

            public static int GetBalance(Node root)
            {
                int balanceFactor = height(root.left) - height(root.right);
                return balanceFactor;
            }

            public static Node LeftRotate(Node parent)
            {
                Node child = parent.right;
                Node T2 = child.left;

                int rankChild = GetRank(parent);
                int rankParent = GetRank(parent.left) + GetRank(child.left) + 1;

                child.left = parent;
                parent.right = T2;

                child.rank = rankChild;
                parent.rank = rankParent;

                child.ht = max(height(child.left), height(child.right)) + 1;
                parent.ht = max(height(parent.left), height(parent.right)) + 1;

                return child;
            }

            public static Node RightRotate(Node parent)
            {
                Node child = parent.left;
                Node T2 = child.right;

                int rankParent = GetRank(child.right) + GetRank(parent.right) + 1;
                int rankChild = GetRank(parent);

                child.right = parent;
                parent.left = T2;

                child.rank = rankChild;
                parent.rank = rankParent;

                child.ht = max(height(child.left), height(child.right)) + 1;
                parent.ht = max(height(parent.left), height(parent.right)) + 1;

                return child;
            }

            public static int height(Node root)
            {
                //return maxDepth(root);
                if (root == null)
                    return -1;
                return root.ht;
            }

            public static int max(int a, int b)
            {
                if (a > b)
                    return a;
                else
                    return b;
            }
        }
    }
    
}
