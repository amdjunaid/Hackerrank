﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stacks
{
    class balancedBrackets
    {
        public class BalancedBrackets
        {
            public static void Solve()
            {
                int n = int.Parse(Console.ReadLine());
                string[] inputs = new string[n];
                for (int i = 0; i < n; i++)
                {
                    inputs[i] = Console.ReadLine();
                }

                foreach (string item in inputs)
                {
                    if (CheckIfBalanced(item))
                    {
                        Console.WriteLine("YES");
                    }
                    else
                        Console.WriteLine("NO");
                }

                Console.Read();
            }

            private static bool CheckIfBalanced(string inputStr)
            {
                bool flag = true;
                char typeAOpen = '{', typeAClosed = '}';
                char typeBOpen = '[', typeBClosed = ']';
                char typeCOpen = '(', typeCClosed = ')';
                Stack<char> stack = new Stack<char>();
                char[] brackets = inputStr.ToCharArray();

                foreach (char item in brackets)
                {
                    if (item.Equals(typeAOpen))
                    {
                        stack.Push(item);
                    }
                    else if (item.Equals(typeAClosed))
                    {
                        char popElement;
                        if (stack.Count > 0)
                        {
                            popElement = stack.Pop();
                            if (!popElement.Equals(typeAOpen))
                            {
                                flag = false;
                                break;
                            }
                        }
                        else
                        {
                            flag = false;
                            break;
                        }
                    }
                    else if (item.Equals(typeBOpen))
                    {
                        stack.Push(item);
                    }
                    else if (item.Equals(typeBClosed))
                    {
                        char popElement;
                        if (stack.Count > 0)
                        {
                            popElement = stack.Pop();
                            if (!popElement.Equals(typeBOpen))
                            {
                                flag = false;
                                break;
                            }
                        }
                        else
                        {
                            flag = false;
                            break;
                        }
                    }
                    else if (item.Equals(typeCOpen))
                    {
                        stack.Push(item);
                    }
                    else if (item.Equals(typeCClosed))
                    {
                        char popElement;
                        if (stack.Count > 0)
                        {
                            popElement = stack.Pop();
                            if (!popElement.Equals(typeCOpen))
                            {
                                flag = false;
                                break;
                            }
                        }
                        else
                        {
                            flag = false;
                            break;
                        }
                    }
                }

                if (flag && stack.Count.Equals(0))
                    return true;
                else
                    return false;
            }
        }
    }
}
