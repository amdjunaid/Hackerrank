﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stacks
{
    public class StackNode
    {
        public long Value { get; set; }
        public long CurrMax { get; set; }
    }
    public class MaximumElement
    {
        public static void Solve()
        {
            long max = long.MinValue;
            Stack<StackNode> stack = new Stack<StackNode>();
            int n = int.Parse(Console.ReadLine());
            string[] inputs = new string[n];

            for (int i = 0; i < n; i++)
            {
                string s = Console.ReadLine();
                inputs[i] = s;
            }
            for (int i = 0; i < n; i++)
            {
                
                if (inputs[i].Equals("2"))
                {
                    while (stack.Peek().CurrMax == max)
                    {
                        stack.Pop();
                    }
                }
                else if (inputs[i].Equals("3"))
                {
                    Console.WriteLine(stack.Peek().CurrMax);
                }
                else
                {
                    string[] str = inputs[i].Split(' ');
                    long num = long.Parse(str[1]);
                    if (num > max)
                        max = num;
                    
                    stack.Push(new StackNode
                    {
                        Value = num,
                        CurrMax = max
                    });
                }
            }

            Console.Read();
        }
    }
}
