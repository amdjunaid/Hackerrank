﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class FindingTheFloor
    {
        static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {
            int N = ReadInt();
            int[] numbers = ReadString().Trim().Split(' ').Select(n => int.Parse(n)).ToArray();
            Array.Sort(numbers);
            int Q = ReadInt();
            while (Q-- > 0)
            {
                int query = ReadInt();
                Console.WriteLine(Floor(numbers, query));
            }
        }

        private static int Floor(int[] arr, int key)
        {
            int lo = 0, hi = arr.Length - 1, mid = 0, ans = 0;
            if (key < arr[lo])
                return int.MinValue;
            else if (key == arr[lo])
                return arr[lo];
            else if (key >= arr[hi])
                return arr[hi];

            while (lo <= hi)
            {
                mid = lo + (hi - lo) / 2;
                if (arr[mid] == key)
                    return arr[mid];
                else if (arr[mid] > key)
                    hi = mid - 1;
                else if (arr[mid] < key)
                {
                    lo = mid + 1;
                    ans = arr[mid];
                }
            }
            return ans;
        }
    }
}
