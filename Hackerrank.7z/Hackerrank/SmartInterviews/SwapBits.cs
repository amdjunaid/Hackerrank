﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    class SwapBitsUnsignedInt
    {
        static void Solve()
        {
            int t = int.Parse(Console.ReadLine());
            UInt32[] output = new UInt32[t];
            for (int i = 0; i < t; i++)
            {
                UInt32 N = UInt32.Parse(Console.ReadLine().Trim());
                output[i] = SwapBits(N);
            }
            foreach (var item in output)
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();
        }
        /// <summary>
        /// /// It is only fruitful to swap two bits if they are exclusive i.e,., 10 <-> 01 and otherwise, 
        /// not required as it would result in the same value.
        /// </summary>
        /// <param name="N">Number to swap</param>
        /// <returns></returns>
        static UInt32 SwapBits(UInt32 N)
        {
            for (int j = 0; j < Math.Ceiling(Math.Log(N, 2)); j += 2)
            {
                UInt32 num = 3;
                if ((N & (1 << j)) != 0) //if jth Bit is set
                {
                    if ((N & (1 << (j + 1))) == 0) // if (j+1)th Bit is unset
                    {
                        num <<= j;
                        N ^= num;
                    }
                }
                else if ((N & (1 << j)) == 0) //if jth Bit is unset
                {
                    if ((N & (1 << (j + 1))) != 0) // if (j+1)th Bit is set
                    {
                        num <<= j;
                        N ^= num;
                    }
                }
            }
            return N;
        }
    }
}


    
