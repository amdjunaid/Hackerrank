﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class FibonacciHard
    {
        static long Modulo = 1000000007;
        static Dictionary<long, long> fib = new Dictionary<long, long>();
        public static void Solve()
        {
            int t = int.Parse(Console.ReadLine());
            while (t-- > 0)
            {
                long number = long.Parse(Console.ReadLine().Trim());
                Console.WriteLine(NthFib(number));
            }
            //Console.ReadLine();
        }

        /// <summary>
        /// Generates Fibonacci number based on n.
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        private static long NthFib(long n)
        {
            if (n == 0 || n == 1) return 1;
            long value;
            if (fib.TryGetValue(n, out value))
            {
                return fib[n];
            }
            long k = n/ 2;

            //if n is odd, F(n) = f(k)*f(k+1) + f(k-1)*f(k)
            if (n % 2 != 0)
            {
                fib.Add(n, (NthFib(k) * NthFib(k + 1) + NthFib(k - 1) * NthFib(k)) % Modulo);
            }
            //if n is even, F(n) = f(k)*f(k) + f(k-1)*f(k-1)
            else
            {
                fib.Add(n, (NthFib(k) * NthFib(k) + NthFib(k - 1) * NthFib(k - 1)) % Modulo);
            }
            return fib[n];
        }
    }
}
