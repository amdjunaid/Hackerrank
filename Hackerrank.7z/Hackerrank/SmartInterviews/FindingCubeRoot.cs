﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class FindingCubeRoot
    {
        //public static void Solve()
        //{
        //    int t = int.Parse(Console.ReadLine().Trim());
        //    while (t-- > 0)
        //    {
        //        long num = long.Parse(Console.ReadLine().Trim());
        //        CubeRoot(num);
        //    }
        //}

        //private static void CubeRoot(long n)
        //{
            
        //}

        //private static long BinarySearch(long n, long lo, long hi)
        //{
        //    long mid = lo + (hi - lo) / 2;   
        //}
    }
}
