﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class PairWithDifferenceKModified
    {
        static long[] numbers = null;
        public static void Solve()
        {
            int t = Solution.Read();
            while (t-- > 0)
            {
                int[] NAndK = Solution.ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                numbers = Solution.ReadString().Split(' ').Select(n => long.Parse(n)).ToArray();
                Console.WriteLine(IsPairWithDiffKPresent(NAndK[1]).ToString().ToLower());
            }
        }

        private static bool IsPairWithDiffKPresent(int k)
        {
            Array.Sort(numbers);
            bool isPairPossible = false;
            for (int i = 0; i < numbers.Length - 1; i++)
            {
                long SecondNumberInPairToFind = numbers[i] + k;
                isPairPossible = IsPairFound(i+1, numbers.Length-1, SecondNumberInPairToFind);
                if (isPairPossible)
                    break;
            }
            return isPairPossible;
        }

        private static bool IsPairFound(int low, int high, long k)
        {
            int lo = low, hi = high, mid;
            bool isSecondNumberFound = false;
            while (lo <= hi)
            {
                mid = lo + (hi - lo) / 2;
                if (numbers[mid].Equals(k))
                {
                    isSecondNumberFound = true;
                    break;
                }
                else if (numbers[mid] < k)
                {
                    lo = mid + 1;
                }
                else if (numbers[mid] > k)
                {
                    hi = mid - 1;
                }
            }
            return isSecondNumberFound;
        }
    }
}
