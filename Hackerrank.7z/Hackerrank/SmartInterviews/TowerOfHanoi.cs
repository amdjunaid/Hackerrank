﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class TowerOfHanoi
    {
        static List<string> movements = null;
        static int NoOfMovements = 0;
        public static void Solve()
        {
            int t = int.Parse(Console.ReadLine().Trim());
            while (t-- > 0)
            {
                NoOfMovements = 0;
                movements = new List<string>();

                int n = int.Parse(Console.ReadLine().Trim());
                TOH(n, 'A', 'C', 'B');
                Console.WriteLine(NoOfMovements);
                foreach (var item in movements)
                {
                    Console.WriteLine(item);
                }
            }
            //Console.ReadLine();
        }

        private static void TOH(int n, char src, char dest, char temp)
        {
            if (n == 0) return;
            TOH(n - 1, src, temp, dest);
            string currentStep = string.Format("Move {0} from {1} to {2}", n, src, dest);
            NoOfMovements++;
            movements.Add(currentStep);
            TOH(n - 1, temp, dest, src);
        }
    }
}
