﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SmartInterviews
{
    public class CabinetPartioning
    {
        static Dictionary<Tuple<int, int>, int> Partitions = new Dictionary<Tuple<int, int>, int>();
        static int[] jobs = null;
        static Func<string> Read = () => Console.ReadLine().Trim();

        public static void Solve()
        {
            short t = short.Parse(Read());
            while (t-- > 0)
            {
                int[] NandK = Read().Split(' ').Select(n => int.Parse(n)).ToArray();
                jobs = Read().Split(' ').Select(n => int.Parse(n)).ToArray();
                FindOptimalJobExecutionTime(NandK[1]);
            }
        }

        private static void FindOptimalJobExecutionTime(int k)
        {
            int MaxTimeToExecute;
            MaxTimeToExecute = jobs[0];
            int MinTime = jobs.Min();
            for (int i = 1; i < jobs.Length; i++)
            {
                MaxTimeToExecute += jobs[i];
            }
            Console.WriteLine(BinarySearch(MinTime, MaxTimeToExecute, k));
        }

        private static int BinarySearch(int lo, int hi, int k)
        {
            int mid = 0;
            while (lo < hi)
            {
                mid = lo + (hi - lo) / 2;
                if (Valid(mid, k))
                {
                    hi = mid;
                }
                else
                {
                    lo = mid + 1;
                }
            }
            return lo;
        }

        private static bool Valid(int mid, int k)
        {
            bool isValid = true;
            int partitionCounter = 0, sum = 0;
            for (int i = 0; i < jobs.Length; i++)
            {
                if (partitionCounter >= k)
                {
                    isValid = false;
                    break;
                }
                sum += jobs[i];
                if (sum < mid)
                {
                    continue;
                }
                else if (sum == mid)
                {
                    partitionCounter += 1;
                    sum = 0;
                }
                else
                {
                    partitionCounter += 1;
                    sum = 0;
                    i--;
                }
            }
            return isValid;
        }
    }
}
