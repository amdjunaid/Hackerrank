﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class NAndItsFreq
    {
        public short n { get; set; }
        public short freq { get; set; }
    }
    public class FrequencySort
    {
        public static void Solve()
        {
            int t = int.Parse(Console.ReadLine().Trim());
            while (t-- > 0)
            {
                short N = short.Parse(Console.ReadLine().Trim());
                short[] numbers = Console.ReadLine().Trim().Split(' ').Select(n => short.Parse(n)).ToArray();
                Sort(numbers, N);
            }
        }

        private static void Sort(short[] numbers, short n)
        {
            short index = 0;
            List<NAndItsFreq> numbersWithFrequency = new List<NAndItsFreq>();
            Dictionary<short, short> reference = new Dictionary<short, short>();
            foreach (var number in numbers)
            {
                if (reference.ContainsKey(number))
                    numbersWithFrequency[reference[number]].freq++;
                else
                {
                    numbersWithFrequency.Insert(index, new NAndItsFreq { n = number, freq = 1 });
                    reference.Add(number, index);
                    index++;
                }
            }

            NAndItsFreq[] sortedArray = numbersWithFrequency.ToArray();
            Array.Sort(sortedArray, delegate (NAndItsFreq x, NAndItsFreq y)
             {
                 if (x.freq.Equals(y.freq))
                 {
                     return x.n.CompareTo(y.n);
                 }
                 return x.freq.CompareTo(y.freq);
             });

            foreach (var item in sortedArray)
            {
                int freq = item.freq;
                while (freq-- > 0)
                    Console.WriteLine(item.n + " ");
            }
            Console.WriteLine();
        }
    }
}
