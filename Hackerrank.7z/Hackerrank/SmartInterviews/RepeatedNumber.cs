﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class RepeatedNumber
    {
        public static void Solve()
        {
            
        }

        //private static Tuple<int,int> BinarySearch(int[] arr)
        //{
        //    Tuple<int, int> result = null;
        //    int lo = 0,hi = arr.Length-1,mid=lo+(hi-lo)/2,ans1=0,ans2=0;
        //    while ()
        //    {
        //        if ((mid + 1).Equals(arr[mid]))
        //        {
        //            lo = mid;
        //        }
        //        else if (mid.Equals(arr[mid]))
        //        {
        //            if ((mid - 1).Equals(arr[mid]))
        //            {
        //                if (ans1.Equals(0))
        //                {
        //                    ans1 = arr[mid];
        //                    mid-1
        //                }
        //                else
        //                {
        //                    ans2 = arr[mid];
        //                    break;
        //                }
        //            }
        //        }
        //    }
        //}
    }
}
