﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class BubbleSort
    {
        public static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        public static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {
            int t = ReadInt();
            while (t-- > 0)
            {
                int N = ReadInt();
                short[] unsortedArray = ReadString().Split(' ').Select(n => short.Parse(n)).ToArray();
                Console.WriteLine(Sort(unsortedArray, N));
            }
        }

        private static int Sort(short[] unsortedArray, int n)
        {
            int noOfSwaps = 0;
            bool isSwapped = true;
            for (int i = 0; (i < n-1) && isSwapped; i++)
            {
                isSwapped = false;
                for (int j = 0; j < n - 1; j++)
                {
                    if (unsortedArray[j + 1] > unsortedArray[j])
                    {
                        noOfSwaps++;
                        short temp = unsortedArray[j];
                        unsortedArray[j] = unsortedArray[j + 1];
                        unsortedArray[j + 1] = temp;
                        //unsortedArray[j] = (short)(unsortedArray[j] ^ unsortedArray[j + 1]);
                        //unsortedArray[j + 1] = (short)(unsortedArray[j] ^ unsortedArray[j + 1]);
                        isSwapped = true;
                    }
                }
            }
            return noOfSwaps;
        }
    }
}
