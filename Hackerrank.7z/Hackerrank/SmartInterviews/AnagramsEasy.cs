﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class AnagramsEasy
    {
        public static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        public static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {
            int t = ReadInt();
            while (t-- > 0)
            {
                string[] input = ReadString().Split(' ').ToArray();
                Console.WriteLine(IsAnagram(input[0],input[1]));
            }

        }

        private static string IsAnagram(string a,string b)
        {
            short[] count = new short[26];
            for (int i = 0; i < a.Length; i++)
            {
                count[a[i] - 'a']++;
            }
            for (int i = 0; i < b.Length; i++)
            {
                count[b[i] - 'a']--;
            }
            for (int i = 0; i < count.Length; i++)
            {
                if (!count[i].Equals(0))
                    return "False";
            }
            return "True";
        }
    }
}
