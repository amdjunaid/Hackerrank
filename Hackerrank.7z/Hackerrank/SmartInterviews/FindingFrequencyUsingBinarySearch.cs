﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class FindingFrequencyUsingBinarySearch
    {
        public static void Solve()
        {
            Dictionary<int, int> map = new Dictionary<int, int>();
            int t = int.Parse(Console.ReadLine().Trim());
            int[] elements = Console.ReadLine().Trim().Split(' ').Select(n => int.Parse(n)).ToArray();
            Array.Sort(elements);
            int q = int.Parse(Console.ReadLine().Trim());
            while (q-- > 0)
            {
                int query = int.Parse(Console.ReadLine().Trim());
                int firstIndex = FindFirstIndex(elements, 0, query),lastIndex = 0;
                if (firstIndex != -1)
                {
                    lastIndex = FindLastIndex(elements,0, query);
                    Console.WriteLine(lastIndex + 1 - firstIndex);
                }
            }
        }

        private static int FindFirstIndex(int[] arr, int startIndex, int Key)
        {
            bool found = false;
            int lo = startIndex, hi = arr.Length - 1, mid = 0, sumofTwoPairedPrefixes = 0;
            while (lo <= hi)
            {
                mid = lo + (hi - lo) / 2;
                sumofTwoPairedPrefixes = arr[mid];
                if (sumofTwoPairedPrefixes.Equals(Key))
                {
                    found = true;
                    hi = mid - 1;
                }
                else if (sumofTwoPairedPrefixes> Key)
                    hi = mid - 1;
                else if (sumofTwoPairedPrefixes < Key)
                    lo = mid + 1;
            }
            if (!found)
                return -1;
            else
                return lo;
        }
        private static int FindLastIndex(int[] arr, int startIndex, int Key)
        {
            int lo = startIndex, hi = arr.Length - 1, mid = 0, sumofTwoPairedPrefixes = 0;
            while (lo <= hi)
            {
                mid = lo + (hi - lo) / 2;
                sumofTwoPairedPrefixes = arr[mid] ;
                if (sumofTwoPairedPrefixes.Equals(Key))
                {
                    lo = mid + 1;
                }
                else if (sumofTwoPairedPrefixes<Key)
                    lo = mid + 1;
                else if (sumofTwoPairedPrefixes>Key)
                    hi = mid - 1;
            }
            return hi;
        }
    }
}
