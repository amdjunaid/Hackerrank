﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public enum Sequence
    {
        Random = 1, Ascending = 2, Descending = 3
    }
    public class Feeder
    {
        public static TextReader reader = null;
        public static TextWriter writer = null;
        public static Func<string, string> ReadStr = null;
        public static Func<int> Read = () => int.Parse(reader.ReadLine().Trim());
        public static Func<string> ReadString = () => reader.ReadLine().Trim();
        public static void Solve()
        {
#if DEBUG
            Console.WriteLine("Enter 1: Random, 2: Asc, 3: Desc Sequence type Please");
            Sequence s = (Sequence)int.Parse(Console.ReadLine().Trim());
            Console.WriteLine("Negative or Positive or Random. false for negative. true for positive.None for Randomness");
            string sign = (Console.ReadLine().Trim().ToLower());
            Console.WriteLine("Enter No of test cases and N value");
            int[] TandN = Console.ReadLine().Split(' ').Select(n => int.Parse(n)).ToArray();
            String RandomInput = FeederMethod(TandN[0], TandN[1], s, sign);
            reader = new StreamReader(GenerateStreamFromString(RandomInput));
            //SmallerElements.writer = new StreamWriter(obj.GetType().Name + " Output.txt");
#else
            SmallerElements.reader = new StreamReader(Console.OpenStandardInput());
            SmallerElements.writer = new StreamWriter(Console.OpenStandardOutput());
#endif
            SubsetSums.Solve();
        }
    static string FeederMethod(int testCases, int N, Sequence order, string sign)
    {
        Random r = new Random();
        StringBuilder str = new StringBuilder();
        str.Append(testCases);
        str.AppendLine();
        for (int i = 0; i < testCases; i++)
        {
                int value = r.Next(-100, 100);
            str.Append(N+" "+value+" "+ (value+10000000));
            str.AppendLine();
            if (order.Equals(Sequence.Random))
                if (sign.Equals("true")) //positive
                    for (int j = 0; j < N; j++)
                    {
                        str.Append(r.Next(1, 1000) + " ");
                    }
                else if (sign.Equals("false")) //negative
                {
                    for (int j = 0; j < N; j++)
                    {
                        str.Append(r.Next(-1000, 1) + " ");
                    }
                }
                else //random
                {
                    for (int j = 0; j < N; j++)
                    {
                        str.Append(r.Next(-1000, 1000) + " ");
                    }
                }

            else if (order.Equals(Sequence.Ascending))
            {
                if (sign.Equals("true"))
                    for (int j = 0; j < N; j++)
                    {
                        str.Append(j + " ");
                    }
                else
                    for (int j = -N; j <= 1; j++)
                    {
                        str.Append(j + " ");
                    }
            }
            else if (order.Equals(Sequence.Descending))
            {
                if (sign.Equals("true"))
                    for (int j = N; j >= 0; j--)
                    {
                        str.Append(j + " ");
                    }
                else
                {
                    int K = -N;
                    while (K++ <=1)
                    {
                        str.Append(K + " ");
                    }
                }
            }
            str.AppendLine();
        }
        return str.ToString();
    }

    static Stream GenerateStreamFromString(string s)
    {
        MemoryStream stream = new MemoryStream();
        StreamWriter writer = new StreamWriter(stream);
        writer.Write(s);
        writer.Flush();
        stream.Position = 0;
        return stream;
    }
}
}
