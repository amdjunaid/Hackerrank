﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class SubsetsOfArray
    {
        public static void Solve()
        {
            int t = int.Parse(Console.ReadLine().Trim());
            while (t-- > 0)
            {
                int N = int.Parse(Console.ReadLine().Trim());
                int[] elements = Console.ReadLine().Trim().Split(' ').Select(n => int.Parse(n)).ToArray();
                Array.Sort(elements);
                GeneratePermutations(elements);
                Console.WriteLine();
            }
            Console.ReadLine();
        }

        private static void GeneratePermutations(int[] elements)
        {
            int n = elements.Length;
            n = 2 << (n - 1);
            int[][] AllPermutations = new int[n - 1][];
            for (int i = 1; i < n; i++)
            {
                int sizeoFCurrentSubset = (int)Math.Ceiling(Math.Log(i, 2))+1;
                List<int> currentSubSet = new List<int>();

                currentSubSet = Enumerable.Repeat(-1, elements.Length).ToList();
                int indexOFCurrentElement = 0;
                for (int j = 0; j < sizeoFCurrentSubset; j++)
                {
                    if ((i & (1 << j)) != 0) // if jth Bit in ith Number is set or not
                    {
                        currentSubSet.Insert(indexOFCurrentElement++, elements[j]);
                    }
                }
                AllPermutations[i - 1] = currentSubSet.Where(num => !num.Equals(-1)).ToArray();
            }

            Array.Sort(AllPermutations, delegate (int[] x, int[] y)
            {
                for (int i = 0; i < Math.Min(x.Length, y.Length); i++)
                {
                    if (x[i].CompareTo(y[i]).Equals(0))
                        continue;
                    return x[i].CompareTo(y[i]);
                }
                return x.Length.CompareTo(y.Length);
            });

            for (int i = 0; i < AllPermutations.Count(); i++)
            {
                foreach (var currentElement in AllPermutations.ElementAt(i))
                {
                    Console.Write(currentElement + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
