﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class PointTheDirectionOfOutput
    {
        public static void Solve()
        {
            int IndexOfFirstAvailableSlot = 0;
            int[] numbers = Console.ReadLine().Trim().Split(' ').Select(n => int.Parse(n)).ToArray();
            int[] outputNumbers = Enumerable.Repeat(-1, numbers.Length).ToArray();
            foreach (var item in numbers)
            {
                IndexOfFirstAvailableSlot = item % 10;
                if (outputNumbers[IndexOfFirstAvailableSlot].Equals(-1))
                {
                    outputNumbers[IndexOfFirstAvailableSlot] = item;
                }
                else
                {
                    while (!outputNumbers[IndexOfFirstAvailableSlot].Equals(-1))
                    {
                        int indexToPushAt = item / 10;
                        if (IndexOfFirstAvailableSlot % 2 == 0) //if even
                        {
                            if (indexToPushAt > (IndexOfFirstAvailableSlot))
                                IndexOfFirstAvailableSlot = ((numbers.Length) - (indexToPushAt - IndexOfFirstAvailableSlot))%(numbers.Length-1);
                            else if(indexToPushAt<=(IndexOfFirstAvailableSlot))
                                IndexOfFirstAvailableSlot -= indexToPushAt;
                        }
                        else
                        {
                            if (indexToPushAt > ((numbers.Length - 1) - IndexOfFirstAvailableSlot))
                            {
                                IndexOfFirstAvailableSlot = (indexToPushAt + IndexOfFirstAvailableSlot) % (numbers.Length - 1);
                                IndexOfFirstAvailableSlot--;
                            }
                            else
                                IndexOfFirstAvailableSlot += indexToPushAt;
                        }
                    }
                    outputNumbers[IndexOfFirstAvailableSlot] = item;
                }
            }
            foreach (var item in outputNumbers)
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();
        }
    }
}
