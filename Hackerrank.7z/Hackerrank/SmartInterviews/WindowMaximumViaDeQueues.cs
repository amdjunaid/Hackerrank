﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

namespace SmartInterviews
{
    public class WindowMaximumViaDeQueues
    {
        static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {

            int t = ReadInt();
            while (t-- > 0)
            {
                int[] NandK = ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                int[] arr = ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                Console.WriteLine(SumofHighestOfKSizeWindows(arr, NandK[0], NandK[1]));
            }
        }

        private static int SumofHighestOfKSizeWindows(int[] arr, int n, int k)
        {
            int sumofHighestOfKSizeWindows = 0, i;

            Dequeue<int> q = new Dequeue<int>();

            for (i = 0; i < k; ++i)
            {
                while (!q.IsEmpty && arr[i] >= arr[q.PeekRare().data])
                    q.PopRare();

                q.PushBack(i);
            }

            for (; i < n; i++)
            {
                sumofHighestOfKSizeWindows += arr[q.PeekFront().data];

                while (!q.IsEmpty && q.PeekFront().data <= i - k)
                    q.PopFront();

                while (!q.IsEmpty && arr[i] >= arr[q.PeekRare().data])
                    q.PopRare();

                q.PushBack(i);
                int count = 
                if (q.Count == 1)
                    sumofHighestOfKSizeWindows += arr[q.PeekFront().data];
            }

            return sumofHighestOfKSizeWindows;
        }
    }

    public class Dequeue<T>
    {
        public int Count;
        Node head = null;
        Node tail = null;
        public class Node
        {
            public T data;
            public Node next;
            public Node prev;
        }

        public Dequeue(T data)
        {
            Node newNode = new Node();
            newNode.data = data;
            head = new Node();
            tail = new Node();
            head.next = newNode;
            newNode.prev = head;
            newNode.next = tail;
            tail.prev = newNode;
            Count = 1;
        }

        public Dequeue()
        {
            head = new Node();
            tail = new Node();
            head.next = tail;
            tail.prev = head;
            Count = 0;
        }

        public void PushFront(T data)
        {
            try
            {
                Node currNode = new Node();
                currNode.data = data;

                Node nodesProceedingHead = head.next;
                currNode.next = nodesProceedingHead;
                nodesProceedingHead.prev = currNode;
                head.next = currNode;
                currNode.prev = head;
                Count++;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void PushBack(T data)
        {
            try
            {
                Node currNode = new Node();
                currNode.data = data;

                Node nodesPreceedingTail = tail.prev;
                nodesPreceedingTail.next = currNode;
                currNode.prev = nodesPreceedingTail;
                currNode.next = tail;
                tail.prev = currNode;
                Count++;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Node PeekFront()
        {
            if (Count == 0)
                return null;
            return head.next;
        }

        public Node PeekRare()
        {
            if (Count == 0)
                return null;
            return tail.prev;
        }

        public Node PopFront()
        {
            if (Count == 0)
            {
                return null;
            }
            Node nodeToDelete = head.next;
            head.next = nodeToDelete.next;
            nodeToDelete.next.prev = head;
            nodeToDelete.next = nodeToDelete.prev = null;
            Count--;
            return nodeToDelete;
        }

        public Node PopRare()
        {
            if (Count == 0)
            {
                return null;
            }
            Node nodeToDelete = tail.prev;
            nodeToDelete.prev.next = tail;
            tail.prev = nodeToDelete.prev;
            nodeToDelete.next = nodeToDelete.prev = null;
            Count--;
            return nodeToDelete;
        }

        public bool IsEmpty
        {
            get
            {
                return Count == 0 ? true : false;
            }
        }
    }
}
