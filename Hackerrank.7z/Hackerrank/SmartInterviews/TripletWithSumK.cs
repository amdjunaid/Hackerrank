﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class TripletWithSumK
    {
        static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {
            int t = ReadInt();
            while (t-- > 0)
            {
                int[] NAndK = ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                int[] numbers = ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                Console.WriteLine(IsTripletFound(numbers, NAndK[1]).ToString().ToLower());
            }
        }
        private static bool IsTripletFound(int[] numbers, int K)
        {
            bool isFound = false;
            int j, k;
            Array.Sort(numbers);
            for (int i = 0; i < numbers.Length; i++) //fix A[i]
            {
                j = i + 1;
                k = numbers.Length - 1;
                while (j < k)
                {
                    int sum = numbers[i] + numbers[j] + numbers[k];
                    if (sum.Equals(K))
                        return isFound = true;
                    else if (sum < K)
                    {
                        j++;
                    }
                    else
                        k--;
                }
            }
            return isFound;
        }
    }
}
