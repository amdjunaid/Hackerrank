﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class PrefixSums
    {
        public long PrefixSum { get; set; }
        public int frequency { get; set; }
    }
    public static class SubsetSums
    {
        enum Relation
        {
            Lesser = 0,
            Between = 1,
            Greater = 2
        }
        static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        static Func<string> ReadString = () => Console.ReadLine().Trim();

        static PrefixSums[] firstHalfSubsetPrefixSums = null;
        static PrefixSums[] secondHalfSubsetPrefixSums = null;

        public static void Solve()
        {
            int t = ReadInt();
            while (t-- > 0)
            {
                int[] NandAandB = ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                int[] elements = ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                int A = NandAandB[1];
                int B = NandAandB[2];
                Console.WriteLine(TotalSubsetsSumsBetweenAandB(elements, A, B));
            }
        }
        private static long TotalSubsetsSumsBetweenAandB(int[] elements, int A, int B)
        {
            long totalSubsetsSumBetweenAandB = 0;
            int firstIndex = 0, lastIndex = 0;
            int n = elements.Length, midIndex = n / 2;
            //Null Set (Sum=0)
            long nullSet = 0;
            totalSubsetsSumBetweenAandB += nullSet.WhatsTheRelation(A, B).Equals(Relation.Between) ? 1 : 0;

            if (n == 1)
            {
                totalSubsetsSumBetweenAandB += elements[0].WhatsTheRelation(A, B).Equals(Relation.Between) ? 1 : 0;
                return totalSubsetsSumBetweenAandB;
            }
            int[] firstHalfOfElements = new int[midIndex];
            int[] secondHalfOfElements = new int[n - midIndex];
            int remainingElementsInSecondHalf = n - (n % 2 != 0 ? midIndex + 1 : midIndex);

            Array.Copy(elements, 0, firstHalfOfElements, 0, midIndex);
            Array.Copy(elements, remainingElementsInSecondHalf, secondHalfOfElements, 0, n - midIndex);

            firstHalfSubsetPrefixSums = GenerateSubsets(firstHalfOfElements, false, true);
            secondHalfSubsetPrefixSums = GenerateSubsets(secondHalfOfElements, true, false);

            // foreach S[i] , binary search in S[j] and findout first and last index to find out frequency of sums. also add S[i] to total sum if its value between A,B.
            foreach (PrefixSums currentSubsetPrefix in firstHalfSubsetPrefixSums)
            {
                firstIndex = FindFirstIndex(currentSubsetPrefix.PrefixSum, 0, A, B);
                if (firstIndex != -1)
                {
                    lastIndex = FindLastIndex(currentSubsetPrefix.PrefixSum, firstIndex, A, B);
                    // find no of elements from first to last index and multiply them with the freq of current prefix to get
                    // total of all such subsets valid within A and B.
                    totalSubsetsSumBetweenAandB += (lastIndex + 1 -  (firstIndex != 0 ? firstIndex : 0)) * currentSubsetPrefix.frequency;
                }
                // Now, individually check for each S[i] within itself for values within A and B.
                totalSubsetsSumBetweenAandB += (currentSubsetPrefix.PrefixSum.WhatsTheRelation(A, B).Equals(Relation.Between)) ? currentSubsetPrefix.frequency : 0;
            }

            // now, similarly for Second half of subsets, check if its values are within A,B, then add to total Sum. 
            // Since we are only checking the second subset values itself and adding nothing to it, so the first parameter is 0.
            firstIndex = FindFirstIndex(0, 0, A, B);
            if (firstIndex != -1)
            {
                lastIndex = FindLastIndex(0, firstIndex, A, B);
                totalSubsetsSumBetweenAandB += lastIndex  + 1 - (firstIndex != 0 ? firstIndex : 0);
            }

            return totalSubsetsSumBetweenAandB;
        }
        private static int FindFirstIndex(long firstPairPrefixSum, int startIndex, int A, int B)
        {
            bool found = false;
            PrefixSums[] arr = secondHalfSubsetPrefixSums;
            int lo = startIndex, hi = arr.Length - 1, mid = 0;
            long sumofTwoPairedPrefixes = 0;
            while (lo <= hi)
            {
                mid = lo + (hi - lo) / 2;
                sumofTwoPairedPrefixes = arr[mid].PrefixSum + firstPairPrefixSum;
                Relation whatsTheRelation = sumofTwoPairedPrefixes.WhatsTheRelation(A, B);
                if (whatsTheRelation.Equals(Relation.Between))
                {
                    found = true;
                    hi = mid - 1;
                }
                else if (whatsTheRelation.Equals(Relation.Greater))
                    hi = mid - 1;
                else if (whatsTheRelation.Equals(Relation.Lesser))
                    lo = mid + 1;
            }
            if (!found)
                return -1;
            else
                return lo;
        }
        private static int FindLastIndex(long firstPairPrefixSum, int startIndex, int A, int B)
        {

            PrefixSums[] arr = secondHalfSubsetPrefixSums;
            int lo = startIndex, hi = arr.Length - 1, mid = 0;
            long sumofTwoPairedPrefixes = 0;
            while (lo <= hi)
            {
                mid = lo + (hi - lo) / 2;
                sumofTwoPairedPrefixes = arr[mid].PrefixSum + firstPairPrefixSum;
                Relation whatsTheRelation = sumofTwoPairedPrefixes.WhatsTheRelation(A, B);
                if (whatsTheRelation.Equals(Relation.Between))
                {
                    lo = mid + 1;
                }
                else if (whatsTheRelation.Equals(Relation.Lesser))
                    lo = mid + 1;
                else if (whatsTheRelation.Equals(Relation.Greater))
                    hi = mid - 1;
            }
            return hi;
        }
        private static PrefixSums[] GenerateSubsets(int[] arr, bool sort, bool requireHashMap)
        {
            PrefixSums currentPrefixSumObj = null;
            // Maps a prefix to its index in the Final Generated Subsets.
            Dictionary<long, int> reference = new Dictionary<long, int>();
            int n = arr.Length, indexOfAllPermutations = 0;
            n = 2 << (n - 1);
            List<PrefixSums> AllPermutations = new List<PrefixSums>(n - 1);
            for (int i = 1; i < n; i++)
            {
                int prefixSumofCurrentSubset = 0;
                int sizeoFCurrentSubset = (int)Math.Ceiling(Math.Log(i, 2)) + 1;

                for (int j = 0; j < sizeoFCurrentSubset; j++)
                {
                    if ((i & (1 << j)) != 0) // if jth Bit in ith Number is set or not
                    {
                        prefixSumofCurrentSubset += arr[j];
                    }
                }
                if (requireHashMap)
                {
                    if (reference.ContainsKey(prefixSumofCurrentSubset))
                    {
                        AllPermutations[reference[prefixSumofCurrentSubset]].frequency++;
                    }
                    else
                    {
                        currentPrefixSumObj = new PrefixSums
                        {
                            PrefixSum = prefixSumofCurrentSubset,
                            frequency = 1
                        };
                        AllPermutations.Insert(indexOfAllPermutations, currentPrefixSumObj);
                        reference.Add(currentPrefixSumObj.PrefixSum, indexOfAllPermutations);
                        indexOfAllPermutations++;
                    }
                }
                else
                {
                    currentPrefixSumObj = new PrefixSums
                    {
                        PrefixSum = prefixSumofCurrentSubset,
                        frequency = 1
                    };
                    AllPermutations.Insert(indexOfAllPermutations++, currentPrefixSumObj);
                }
            }

            PrefixSums[] AllPermutationsArray = AllPermutations.ToArray();
            if (sort)
                Array.Sort(AllPermutationsArray, delegate (PrefixSums prefixSum1, PrefixSums prefixSum2)
                {
                    return prefixSum1.PrefixSum.CompareTo(prefixSum2.PrefixSum);
                });
            return AllPermutationsArray;
        }
        private static Relation WhatsTheRelation<T>(this T K, int A, int B)
        {
            dynamic k = K;
            Relation relation = Relation.Between;
            if (k >= A && k <= B)
                relation = Relation.Between;
            else if (k < A)
                relation = Relation.Lesser;
            else if (k > B)
                relation = Relation.Greater;
            return relation;
        }
    }
}
