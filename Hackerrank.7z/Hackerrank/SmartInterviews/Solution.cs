﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace SmartInterviews
{
    class Solution
    {
        public static Func<int> Read = () => int.Parse(Console.ReadLine().Trim());
        public static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Main(String[] args)
        {
            WindowMaximumViaDeQueues.Solve();
        }
    }
}
