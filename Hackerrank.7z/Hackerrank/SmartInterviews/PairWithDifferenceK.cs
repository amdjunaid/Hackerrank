﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class PairWithDifferenceK
    {
        public static void Solve()
        {
            int t = Solution.Read();
            while (t-- > 0)
            {
                int[] NAndK = Solution.ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                int[] numbers = Solution.ReadString().Split(' ').Select(n => int.Parse(n)).ToArray();
                Console.WriteLine(IsPairWithDiffKPresent(numbers, NAndK[1]).ToString().ToLower());
            }
        }

        private static bool IsPairWithDiffKPresent(int[] numbers, int K)
        {
            bool isPresent = false;
            Dictionary<int, List<int>> map = new Dictionary<int, List<int>>();
            for (int i = 0; i < numbers.Length; i++) // store b+k in Dictionary.
            {
                int addedNumber = numbers[i] + K;
                if (map.ContainsKey(addedNumber))
                    map[addedNumber].Add(i);
                else
                    map.Add(addedNumber, new List<int> { i });
            }

            for (int i = 0; i < numbers.Length; i++)
            {
                if (map.ContainsKey(numbers[i]))
                {
                    foreach (var item in map[numbers[i]])
                    {
                        if (!item.Equals(i))
                        {
                            isPresent = true;
                            break;
                        }
                    }
                }
            }
            return isPresent;
        }
    }
}
