﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class InsertionSort
    {
        public static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        public static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {
            int t = ReadInt();
            while (t-- > 0)
            {
                int N = ReadInt();
                short[] unsortedArray = ReadString().Split(' ').Select(n => short.Parse(n)).ToArray();
                Console.WriteLine(Sort(unsortedArray, N));
            }
        }

        private static string Sort(short[] unsortedArray, int n)
        {
            StringBuilder positionsAtWhichSwapOccurs = new StringBuilder();
            for (int i = 1; i < n; i++)
            {
                int j = i;
                while (j > 0)
                {
                    if (unsortedArray[j - 1] > unsortedArray[j])
                    {
                        short temp = unsortedArray[j];
                        unsortedArray[j] = unsortedArray[j - 1];
                        unsortedArray[j - 1] = temp;
                        j--;
                    }
                    else
                        break;
                }
                positionsAtWhichSwapOccurs.Append(j + " ");
            }
            return positionsAtWhichSwapOccurs.ToString();
        }
    }
}
