﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class SelectionSort
    {
        static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {
            int t = ReadInt();
            while (t-- > 0)
            {
                short N = short.Parse(ReadString());
                short[] numbers = ReadString().Split(' ').Select(n => short.Parse(n)).ToArray();
                Console.WriteLine(PrintPositionsSwapped(numbers, N));
                Console.WriteLine();
            }
        }

        private static string PrintPositionsSwapped(short[] numbers, short n)
        {
            StringBuilder str = new StringBuilder();
            int minIndex = 0;
            for (int i = 0; (i < n); i++)
            {
                minIndex = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (numbers[minIndex] > numbers[j])
                    {
                        minIndex = j;
                        break;
                    }
                }
                if (minIndex!= i)
                {
                    short temp = numbers[i];
                    numbers[i] = numbers[minIndex];
                    numbers[minIndex] = temp;
                    str.Append(minIndex + " ");
                }
            }
            return str.AppendLine().ToString();
        }
    }
}
