﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class EnclosingSubstring
    {
        public static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        public static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {
            int t = ReadInt();
            while (t-- > 0)
            {
                string[] AandB= ReadString().Split(' ').ToArray();
                Console.WriteLine(SmallestSubStringOfB(AandB[0], AandB[1]));
            }
        }

        private static int SmallestSubStringOfB(string A, string B)
        {
            Dictionary<int, int> charCountOfA = new Dictionary<int, int>();
            Dictionary<int, int> charCountOfB = new Dictionary<int, int>();
            int P1 = 0,P2=1;
            int indexOfCurrCharacter = 0;

            #region InitializingMappers
            for (int i = 0; i < A.Length; i++)
            {
                indexOfCurrCharacter = (A[i] - 'a');
                if (charCountOfA.ContainsKey(indexOfCurrCharacter))
                {
                    charCountOfA[indexOfCurrCharacter]++;
                }
                else
                {
                    charCountOfA.Add(indexOfCurrCharacter, 1);
                }
            }

            #endregion

            if (B.Length.Equals(1)) // if B has only 1 character
            {
                if (charCountOfA.Count > 1) // if A has more than 1 distinct character, then A is not a subset of B
                    return -1;
                else //if A has only 1 distinct character
                {
                    int firstCharacterOfB = (B[0] - 'a'); //pick the index of 1st character in B
                    if(!charCountOfA[firstCharacterOfB].Equals(1)) // if the count of the above character in A is not equal to 1, then A is not subset of B
                        return -1;
                }
            }

            charCountOfB.Add(B[P1] - 'a', 1);
            if (B[P1].Equals(B[P2]))
                charCountOfB[B[P1] - 'a']++;
            else
                charCountOfB.Add(B[P1] - 'a', 1);

            while (P1 < P2)
            {
                foreach (var item in charCountOfB.Keys)
                {
                    if (charCountOfA.ContainsKey(item))
                    {

                    }
                }
            }

            return 0;
        }
    }
}
