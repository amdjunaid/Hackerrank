﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class FindingTheCubeRoot
    {
        static Func<int> ReadInt = () => int.Parse(Console.ReadLine().Trim());
        static Func<string> ReadString = () => Console.ReadLine().Trim();
        public static void Solve()
        {
            int t = ReadInt();
            while (t-- > 0)
            {
                long N = long.Parse(ReadString());
                Console.WriteLine(CubeRoot(N));
            }
        }

        private static long CubeRoot(long n)
        {
            bool isPositive = true;
            if (n > 0)
            {
                isPositive = true;
            }
            else
            {
                isPositive = false;
                n = -n;
            }


            long lo = 1, hi = (long)Math.Sqrt(n), mid = 0, ans = 0;
            while (lo <= hi)
            {
                mid = lo + (hi - lo) / 2;
                long proposedCubeRoot = (mid * mid), divisor = (n / mid);
                if (proposedCubeRoot == divisor)
                {
                    ans = isPositive ? mid : -mid;
                    break;
                }
                else if (proposedCubeRoot < (divisor))
                    lo = mid + 1;
                else if (proposedCubeRoot > (divisor))
                    hi = mid;
            }
            return ans;
        }
    }
}
