﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartInterviews
{
    public class FindingFrequency
    {
        public static void Solve()
        {
            Dictionary<int, int> map = new Dictionary<int, int>();
            int t = int.Parse(Console.ReadLine().Trim());
            int[] elements = Console.ReadLine().Trim().Split(' ').Select(n => int.Parse(n)).ToArray();
            foreach (var number in elements)
            {
                if (map.ContainsKey(number))
                    map[number]++;
                else
                    map.Add(number, 1);
            }
            int q= int.Parse(Console.ReadLine().Trim());
            while (q-- > 0)
            {
                int query = int.Parse(Console.ReadLine().Trim());
                if(map.ContainsKey(query))
                    Console.WriteLine(map[query]);
                else
                    Console.WriteLine(0);
            }
        }
    }
}
